This is a test program! It includes five files, The main program is test. You can input following these instructions to run this program.

You can construct your own MenuList by inputing Command and Description.Menu model provides some functions for you,for example add command to menulist,delete command for menulist,delet menulist and find out command from menulist.


Bulid Procedure
	$ gcc test.c -o test
	$ ./test # you can do some operations accroding to the message.
notice:	
	1.Please don't input space when you input the description of Command.Thanks for your coorperation.
	2.Menu model provides the handler of help and quit,If you want to use it,please input command:help or quit.
