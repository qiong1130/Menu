/***************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015 					           */
/*                                                                                                 */
/* FILE NAME             :  menu.h                                                                 */
/* PRINCIPAL AUTHOR      :  Hanqiong  				             			   */ 
/* SUBSYSTEM NAME        :  menu				                                   */
/* MODULE NAME           :  menu                                                                   */
/* LANGUAGE              :  C                                                                      */
/* TARGET ENVIRONMENT    :  ANY                                                                    */
/* DATE OF FIRST RELEASE :  2014/09/21                                                             */
/* DESCRIPTION           :  This is a menu program                                                 */
/***************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/21
 *
 */

#include"linktable.c"

#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 10

/* data struct and its operations */
typedef struct DataNode
{
	tLinkTableNode * pNext;
	char* cmd;
	char* desc;
	int (*handler)();
}tDataNode;

/* find a cmd in the linklist and return * ppLinktable);*/
tDataNode* FindCmd(tLinkTable * head, char * cmd);

/* InitMenuData */
int InitMenuData(tLinkTable ** ppLinktable);

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head);


/* delete menulist */
int DeleteMenuList(tLinkTable ** ppLinkTable);

/* add Command */
int AddCommand(tLinkTable ** ppLinkTable);

/* Delete a Command from menulist */
int DeleteCommand(tLinkTable ** ppLinkTable);





