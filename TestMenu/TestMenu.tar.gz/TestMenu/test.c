/***************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015 					           */
/*                                                                                                 */
/* FILE NAME             :  test.c                                                                 */
/* PRINCIPAL AUTHOR      :  Hanqiong  				             	                   */ 
/* SUBSYSTEM NAME        :  test					                           */
/* MODULE NAME           :  test                                                                   */
/* LANGUAGE              :  C                                                                      */
/* TARGET ENVIRONMENT    :  ANY                                                                    */
/* DATE OF FIRST RELEASE :  2014/09/21                                                             */
/* DESCRIPTION           :  This is a menu program                                                 */
/***************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/21
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.c"

tLinkTable * head = NULL;
/* menu program */
main()
{
	int n;
	printf("*********Construct Your Own MenuLiist********\n");
	InitMenuData(&head);
	printf("\n************ShowAllCommand**********\n");
	ShowAllCmd(head);
	/* cmd line begins */
	while(1)
	{
		printf("1.ShowAllcmd 2.FindCommand 3.AddCommand 4.DeleteCommand 5.DeleteMenuList 6.Quit\n");
		printf("	please input the number of operation: ");
		scanf("%d", &n);
		switch(n)
		{
			case 1:
					ShowAllCmd(head);
					break;
			case 2:
					FindCommand(head);
					break;
			case 3:
					AddCommand(&head);
					break;
			case 4:
					DeleteCommand(&head);
					break;
			case 5:
					DeleteMenuList(&head);
					break;
			case 6:
					exit(0);
					break;
			default:
					printf("The number of operation is wrong!\n");
					break;
		}
		printf("\n");
	}
}

int FindCommand(tLinkTable * head)
{
	char cmd[CMD_MAX_LEN];
	printf("Input a cmd number > ");
	scanf("%s", cmd);
	tDataNode *p = FindCmd(head, cmd);
	if( p == NULL)
	{
		printf("	This is a wrong command!\n ");
	}
	printf("%s - %s\n", p->cmd, p->desc);
	if(p->handler != NULL)
	{
		p->handler();
	}
}
int Help()
{
	ShowAllCmd(head);
	return 0;
}
int Quit()
{
	exit(0);
}
