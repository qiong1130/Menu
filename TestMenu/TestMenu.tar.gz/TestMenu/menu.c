/*************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015				                 */
/*                                                                                               */
/* FILE NAME             :   menu.c                                                              */
/* PRINCIPAL AUTHOR      :   Hanqiong 			                                         */ 
/* SUBSYSTEM NAME        :   men                                                                 */
/* MODULE NAME           :   menu                                                                */
/* LANGUAGE              :   C                                                                   */
/* TARGET ENVIRONMENT    :   ANY                                                                 */
/* DATE OF FIRST RELEASE :   2014/09/21                                                          */
/* DESCRIPTION           :   This is a menu program                                              */
/*************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/21
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include"menu.h"

int Help();
int Quit();

/* InitMenuData */
int InitMenuData(tLinkTable ** ppLinktable)
{
	int i,n;
	char HELP[10]="help";
	char QUIT[10]="quit";
	*ppLinktable = CreateLinkTable();
	printf("	Please input the number of menus: ");
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{ 
		char* a=(char *)malloc(100);
		char* b=(char *)malloc(100);
		tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
		printf("    Command: ");
		scanf("%s", a);
		pNode->cmd=a;
		printf("    description: ");
		scanf("%s", b);
		pNode->desc=b;
		if(!strcmp(pNode->cmd, HELP))
		{
			pNode->handler=Help;
		}
		else if(!strcmp(pNode->cmd, QUIT))
		{
			pNode->handler=Quit;
		}
		else
		{
			pNode->handler = NULL;
		}
		AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
	}
	return 0;
}

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
	tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
	while(pNode != NULL)
	{
		if(!strcmp(pNode->cmd, cmd))
		{
			return pNode;
		}
		pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
	}
	return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
	tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
	if(pNode == NULL)
	{
		printf("	The MenuList is NULL\n");
	}
	while(pNode != NULL)
	{
		printf("	%s - %s\n", pNode->cmd, pNode->desc);
		pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
	}
	return 0;
}

/* delete menulist */
int DeleteMenuList(tLinkTable ** ppLinkTable)
{
	int i;
	i=DeleteLinkTable(* ppLinkTable);
	if(i==0)
	{
		printf("	Delete MenuList successfully!\n");
	}
	else
	{
		printf("	The MenuList is NULL!\n");
	}
}

/* add Command */
int AddCommand(tLinkTable ** ppLinkTable)
{	
	char* a=(char *)malloc(100);
	char* b=(char *)malloc(100);
	tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
	printf("Input the name of Command: ");
	scanf("%s", a);
	pNode->cmd=a;
	printf("Input the description of Command: ");
	scanf("%s", b);
	pNode->desc=b;
	tDataNode * p1=FindCmd(* ppLinkTable, pNode->cmd);
	if(p1!= NULL)
	{
		printf("	The command exists !\n");
	}
	else 
	{
		AddLinkTableNode(*ppLinkTable, (tLinkTableNode *)pNode);
		printf("	Add Command successfully!\n");
	}	
}

/* Delete a Command from menulist */
int DeleteCommand(tLinkTable ** ppLinkTable)
{
	char * Cmd;
	int i;
	tDataNode * pNode = NULL; 
	printf("Please input command(delete): ");
	scanf("%s", Cmd);	
	pNode=FindCmd(*ppLinkTable, Cmd);
	i=DelLinkTableNode(*ppLinkTable, (tLinkTableNode *)pNode);
	if(i == 0)
	{
		printf("	Delete command successfuly!\n");
	}
	else
	{
		printf("	The menu list is NULL!\n");
	}
}


