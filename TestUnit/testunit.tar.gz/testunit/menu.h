/*************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015 					       						 */
/*                                                                                               */
/* FILE NAME             :  menu.h                                                               */
/* PRINCIPAL AUTHOR      :  Hanqiong  				             		        			     */ 
/* SUBSYSTEM NAME        :  menu				                                 			     */
/* MODULE NAME           :  menu                                                                 */
/* LANGUAGE              :  C                                                                    */
/* TARGET ENVIRONMENT    :  ANY                                                                  */
/* DATE OF FIRST RELEASE :  2014/09/28                                                           */
/* DESCRIPTION           :  This is a menu program                                               */
/*************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/28
 *
 */


#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 10

/* data struct and its operations */
typedef struct LinkTable tLinkTable;
typedef struct LinkTableNode tLinkTableNode;


/* InitMenuData */
int InitMenuData(tLinkTable * head);

/* find a cmd in the linklist and return * ppLinktable);*/
int FindCmd(tLinkTable * head, char * cmd);

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head);


/* delete menulist */
int DeleteMenuList(tLinkTable * head);

/* add Command */
int AddCommand(tLinkTable * head,char * cmd);

/* Delete a Command from menulist */
int DeleteCommand(tLinkTable * head,char * cmd);





