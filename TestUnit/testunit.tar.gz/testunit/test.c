/**************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015 						  */
/*                                                                                                */
/* FILE NAME             :  test.c                                                                */
/* PRINCIPAL AUTHOR      :  Hanqiong  				             	                  */ 
/* SUBSYSTEM NAME        :  test			                                          */
/* MODULE NAME           :  test                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATE OF FIRST RELEASE :  2014/09/28                                                            */
/* DESCRIPTION           :  This is a menu program                                                */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/28
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.c"


int results[18] = {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
char * info[18] =
{
	"test report",
	"TC1: InitMenuData",
	"TC2.1: ShowAllCmd(head!=NULL)",
	"TC2.2: ShowAllCmd(head=NULL)",
	"TC3.1: FindCommand(head=NULL,pNode=NULL)",
	"TC3.2: FindCommand(head=NULL,pNOde!=NULL)",
	"TC3.2: FindCommand(head!=NULL,pNOde=NULL)",
	"TC3.4: FindCommand(head!=NULL,pNOde!=NULL)",
	"TC4.1: AddCommand(head=NULL,pNOde=NULL)",
	"TC4.2: AddCommand(head!=NULL,pNOde=NULL)",
	"TC4.3: AddCommand(head=NULL,pNOde!=NULL)",
	"TC4.4: AddCommand(head!=NULL,pNOde!=NULL)",
	"TC5.1: DelCommand(head=NULL,pNOde=NULL)",
	"TC5.2: DelCommand(head=NULL,pNOde!=NULL)",
	"TC5.3: DelCommand(head!=NULL,pNOde=NULL)",
	"TC5.4: DelCommand(head!=NULL,pNOde!=NULL)",
	"TC6.1: DelMenuList(head!=NULL)",
	"TC6.2: DelMenuList(head=NULL)"	
};

//tLinkTable * pLinkTable = (tLinkTable *)malloc(sizeof(tLinkTable));

char * cmd1 = {" "};
char * cmd2 = NULL;
/* menu program */
main()
{
	tLinkTable * head1 = (tLinkTable *)malloc(sizeof(tLinkTable));
	tLinkTable * head2 = NULL;
	int i;
/* Test InitMenuData */
	head2=NULL;
	i=InitMenuData(head2);
	if(i==0)
	{
		results[1] = 0;	
	}
/* Test ShowAllCmd */
	/* Test ShowAllCmd situation 1*/	
	int showRet=ShowAllCmd(head1);
	if(showRet==0)
	{
		results[2] = 0;	
	}
	else
	{
		results[2] = 1;
	}
	/* Test ShowAllCmd situation 2*/			
	showRet=ShowAllCmd(head2);
	if(showRet==0)
	{
		results[3] = 1;	
	}
	else
	{
		results[3] = 0;
	}
/* Test FindCommand */	
	/* test FindCmd situation 1 */
	int FindRet=FindCmd(head2,cmd2);
	if(FindRet==0)
	{
		results[4] = 1;	
	}
	else
	{
		results[4] = 0;	
	}
	/* test FindCmd situation 2 */
	FindRet=FindCmd(head2,cmd1);
	if(FindRet==0)
	{
		results[5] = 1;	
	}
	else
	{
		results[5] = 0;	
	}
	/* test FindCmd situation 3 */
	FindRet=FindCmd(head1,cmd2);
	if(FindRet==0)
	{
		results[6] = 1;	
	}
	else
	{
		results[6] = 0;	
	}
	/* test FindCmd situation 4 */
	FindRet=FindCmd(head1,cmd1);
	if(FindRet==0)
	{
		results[7] = 0;	
	}
	else
	{
		results[7] = 1;	
	}
/* Test AddCommand */
	/* Test AddCommand situation 1*/
	int ADDRet=AddCommand(head2,cmd2);
	if(ADDRet==0)
	{
		results[8] = 1;	
	}
	else
	{
		results[8] = 0;
	}
	/* Test AddCommand situation 2*/
	ADDRet=AddCommand(head1,cmd2);
	if(ADDRet==0)
	{
	
		results[9] = 1;	
	}
	else
	{
		results[9] = 0;
	}
	/* Test AddCommand situation 3*/
	ADDRet=AddCommand(head2,cmd1);
	if(ADDRet==0)
	{
		results[10] = 1;	
	}
	else
	{
		results[10] = 0;
	}
	/* Test AddCommand situation 4*/
	ADDRet=AddCommand(head1,cmd1);
	if(ADDRet==0)
	{
		results[11] = 0;	
	}
	else
	{
		results[11] = 1;
	}
/* Test DeleteCommand */
	/* Test DeleteCommand situation 1*/
	int DelCmdRet=DeleteCommand(head2,cmd2);
	if(DelCmdRet==0)
	{
		results[12] = 1;	
	}
	else
	{
		results[12] = 0;	
	}
	/* Test DeleteCommand situation 2*/
	DelCmdRet=DeleteCommand(head2,cmd1);
	if(DelCmdRet==0)
	{
		results[13] = 1;	
	}
	else
	{
		results[13] = 0;	
	}
	/* Test DeleteCommand situation 3*/
	DelCmdRet=DeleteCommand(head1,cmd2);
	if(DelCmdRet==0)
	{
		results[14] = 1;	
	}
	else
	{
		results[14] = 0;	
	}
	/* Test DeleteCommand situation 4*/
	DelCmdRet=DeleteCommand(head1,cmd1);
	if(DelCmdRet==0)
	{
		results[15] = 0;	
	}
	else
	{
		results[15] = 1;	
	}

/* Test DeleteMenuList */
	/* Test DeleteMenuList situation 1*/
	int DelMenuRet=DeleteMenuList(head1);
	if(DelMenuRet==0)
	{
		results[16] = 0;	
	}
	else
	{
		results[16] = 1;	
	}
	/* Test DeleteMenuList situation 2*/
	DelMenuRet=DeleteMenuList(head2);
	if(DelMenuRet==0)
	{
		results[17] = 1;	
	}
	else
	{
		results[17] = 0;	
	}
/* printf Test Report */
	printf("*****************Test Report*****************\n");
	printf("	Function	   			Restults			\n");
	for(i=1;i<18;i++)
	{
		printf("    %s",info[i]);
		if(results[i]==1)
		{		
			printf("	 	 Failure\n");
		}
		else
		{
			printf("	  	 Success\n");
		}
	}
}

