/*************************************************************************************************/
/* Copyright (C) hanqiong.com, SSE-USTC, 2014-2015				               	 */
/*                                                                                               */
/* FILE NAME             :   menu.c                                                              */
/* PRINCIPAL AUTHOR      :   Hanqiong 			                                         */ 
/* SUBSYSTEM NAME        :   men                                                                 */
/* MODULE NAME           :   menu                                                                */
/* LANGUAGE              :   C                                                                   */
/* TARGET ENVIRONMENT    :   ANY                                                                 */
/* DATE OF FIRST RELEASE :   2014/09/28                                                          */
/* DESCRIPTION           :   This is a menu program                                              */
/*************************************************************************************************/

/*
 *Revision log:
 *
 *Created by Hanqiong, 2014/09/28
 *
 */
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include"menu.h"

typedef struct LinkTable
{

}tLinkTable;

typedef struct LinkTableNode
{

}tLinkTableNode;

int InitMenuData(tLinkTable * head)
{
	return 0;
}

int FindCmd(tLinkTable * head, char * cmd)
{
	if(head == NULL|| cmd == NULL)
	{
		return 1;
	}
	else if(head != NULL && cmd == NULL)
	{
		return 1;
	}
	else if(head == NULL && cmd != NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int ShowAllCmd(tLinkTable * head)
{
	if(head == NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int DeleteMenuList(tLinkTable * head)
{
	if(head==NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int AddCommand(tLinkTable * head,char * cmd)
{	
	if(head == NULL||cmd == NULL)
	{
		return 1;
	}
	else if(head != NULL && cmd == NULL)
	{
		return 1;
	}
	else if(head == NULL && cmd != NULL)
	{
		
		return ShowAllCmd(head);
	}
	else
	{
		return ShowAllCmd(head);
	}
}

int DeleteCommand(tLinkTable * head,char * cmd)
{
	if(head == NULL|| cmd == NULL)
	{
		return 1;
	}
	else if(head != NULL && cmd == NULL)
	{
		return 1;
	}
	else if(head == NULL && cmd != NULL)
	{
		return 1;
	}
	else
	{
		return ShowAllCmd(head);
	}	
}







